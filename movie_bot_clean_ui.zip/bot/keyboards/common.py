from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def back_home_kb(lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if lang == "bn":
        builder.row(
            InlineKeyboardButton(text="⬅️ ফিরে যান", callback_data="back", style="primary"),
            InlineKeyboardButton(text="🏠 হোম", callback_data="home", style="primary")
        )
    else:
        builder.row(
            InlineKeyboardButton(text="⬅️ Back", callback_data="back", style="primary"),
            InlineKeyboardButton(text="🏠 Home", callback_data="home", style="primary")
        )
    return builder.as_markup()


def cancel_kb(lang: str = "bn") -> InlineKeyboardMarkup:
    text = "❌ বাতিল" if lang == "bn" else "❌ Cancel"
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=text, callback_data="cancel", style="danger"))
    return builder.as_markup()


def confirm_kb(yes_data: str, no_data: str = "cancel", lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    yes = "✅ নিশ্চিত" if lang == "bn" else "✅ Confirm"
    no = "❌ না" if lang == "bn" else "❌ No"
    builder.row(
        InlineKeyboardButton(text=yes, callback_data=yes_data, style="success"),
        InlineKeyboardButton(text=no, callback_data=no_data, style="danger")
    )
    return builder.as_markup()


def language_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="বাংলা 🇧🇩", callback_data="lang_bn", style="primary"),
        InlineKeyboardButton(text="English 🇺🇸", callback_data="lang_en", style="primary")
    )
    return builder.as_markup()
