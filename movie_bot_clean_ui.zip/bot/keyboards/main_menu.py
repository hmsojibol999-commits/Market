from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu_kb(is_admin: bool = False, lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    if lang == "bn":
        builder.row(
            InlineKeyboardButton(text="🔍 সার্চ", callback_data="search", style="primary"),
            InlineKeyboardButton(text="👤 প্রোফাইল", callback_data="profile", style="primary")
        )
        builder.row(
            InlineKeyboardButton(text="🔗 রেফার", callback_data="refer", style="primary"),
            InlineKeyboardButton(text="🎁 প্রোমো কোড", callback_data="promo_code", style="success")
        )
        builder.row(
            InlineKeyboardButton(text="💎 প্রিমিয়াম", callback_data="premium", style="success"),
            InlineKeyboardButton(text="🪙 ক্রেডিট আনলক", callback_data="earn_credit", style="success")
        )
        builder.row(
            InlineKeyboardButton(text="💬 সাপোর্ট", callback_data="support", style="primary"),
            InlineKeyboardButton(text="📝 ফিডব্যাক", callback_data="feedback", style="primary")
        )
        builder.row(
            InlineKeyboardButton(text="🛠️ টুলস / APK", callback_data="tools", style="primary")
        )
        if is_admin:
            builder.row(
                InlineKeyboardButton(text="⚙️ অ্যাডমিন প্যানেল", callback_data="admin_panel", style="danger")
            )
    else:
        builder.row(
            InlineKeyboardButton(text="🔍 Search", callback_data="search", style="primary"),
            InlineKeyboardButton(text="👤 Profile", callback_data="profile", style="primary")
        )
        builder.row(
            InlineKeyboardButton(text="🔗 Refer", callback_data="refer", style="primary"),
            InlineKeyboardButton(text="🎁 Promo Code", callback_data="promo_code", style="success")
        )
        builder.row(
            InlineKeyboardButton(text="💎 Premium", callback_data="premium", style="success"),
            InlineKeyboardButton(text="🪙 Unlock Credit", callback_data="earn_credit", style="success")
        )
        builder.row(
            InlineKeyboardButton(text="💬 Support", callback_data="support", style="primary"),
            InlineKeyboardButton(text="📝 Feedback", callback_data="feedback", style="primary")
        )
        builder.row(
            InlineKeyboardButton(text="🛠️ Tools / APK", callback_data="tools", style="primary")
        )
        if is_admin:
            builder.row(
                InlineKeyboardButton(text="⚙️ Admin Panel", callback_data="admin_panel", style="danger")
            )

    return builder.as_markup()


def search_type_kb(lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if lang == "bn":
        builder.row(
            InlineKeyboardButton(text="🎬 মুভি", callback_data="search_movie", style="primary"),
            InlineKeyboardButton(text="📺 সিরিজ", callback_data="search_series", style="primary")
        )
        builder.row(InlineKeyboardButton(text="⬅️ ফিরে যান", callback_data="home", style="primary"))
    else:
        builder.row(
            InlineKeyboardButton(text="🎬 Movie", callback_data="search_movie", style="primary"),
            InlineKeyboardButton(text="📺 Series", callback_data="search_series", style="primary")
        )
        builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="home", style="primary"))
    return builder.as_markup()


def movie_result_kb(movie_id: int, is_premium: bool, has_credit: bool, lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if lang == "bn":
        if is_premium or has_credit:
            builder.row(
                InlineKeyboardButton(text="▶️ অনলাইনে দেখুন", callback_data=f"watch_{movie_id}_720", style="success")
            )
            if is_premium:
                builder.row(
                    InlineKeyboardButton(text="⬇️ ডাউনলোড (১০৮০)", callback_data=f"download_{movie_id}_1080", style="primary")
                )
        else:
            builder.row(
                InlineKeyboardButton(text="💎 প্রিমিয়াম নিন", callback_data="premium", style="success")
            )
        builder.row(InlineKeyboardButton(text="⬅️ ফিরে যান", callback_data="search", style="primary"))
    else:
        if is_premium or has_credit:
            builder.row(
                InlineKeyboardButton(text="▶️ Watch Online", callback_data=f"watch_{movie_id}_720", style="success")
            )
            if is_premium:
                builder.row(
                    InlineKeyboardButton(text="⬇️ Download (1080)", callback_data=f"download_{movie_id}_1080", style="primary")
                )
        else:
            builder.row(
                InlineKeyboardButton(text="💎 Get Premium", callback_data="premium", style="success")
            )
        builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="search", style="primary"))
    return builder.as_markup()


def series_episodes_kb(movie_id: int, total_eps: int, is_premium: bool, lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for ep in range(1, min(total_eps + 1, 31)):  # max 30 buttons safety
        builder.add(
            InlineKeyboardButton(
                text=f"EP {ep}",
                callback_data=f"watch_ep_{movie_id}_{ep}",
                style="primary"
            )
        )
    builder.adjust(3)
    back_text = "⬅️ ফিরে যান" if lang == "bn" else "⬅️ Back"
    builder.row(InlineKeyboardButton(text=back_text, callback_data="search", style="primary"))
    return builder.as_markup()


def force_join_kb(update_link: str, backup_link: str, lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if lang == "bn":
        builder.row(InlineKeyboardButton(text="📢 আপডেট চ্যানেল জয়েন করুন", url=update_link, style="primary"))
        builder.row(InlineKeyboardButton(text="📢 ব্যাকআপ চ্যানেল জয়েন করুন", url=backup_link, style="primary"))
        builder.row(InlineKeyboardButton(text="✅ জয়েন করেছি, চেক করুন", callback_data="check_join", style="success"))
    else:
        builder.row(InlineKeyboardButton(text="📢 Join Update Channel", url=update_link, style="primary"))
        builder.row(InlineKeyboardButton(text="📢 Join Backup Channel", url=backup_link, style="primary"))
        builder.row(InlineKeyboardButton(text="✅ Joined, Check", callback_data="check_join", style="success"))
    return builder.as_markup()
