from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_panel_kb(lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if lang == "bn":
        builder.row(InlineKeyboardButton(text="👤 ইউজার ম্যানেজ", callback_data="admin_user", style="primary"))
        builder.row(InlineKeyboardButton(text="🎬 মুভি/সিরিজ ম্যানেজ", callback_data="admin_movies", style="primary"))
        builder.row(InlineKeyboardButton(text="💳 পেমেন্ট সেটআপ", callback_data="admin_payment", style="primary"))
        builder.row(InlineKeyboardButton(text="📦 সাবস্ক্রিপশন প্ল্যান", callback_data="admin_plans", style="primary"))
        builder.row(InlineKeyboardButton(text="🧾 অর্ডার / পেন্ডিং", callback_data="admin_orders", style="success"))
        builder.row(InlineKeyboardButton(text="📩 মুভি রিকোয়েস্ট", callback_data="admin_requests", style="primary"))
        builder.row(InlineKeyboardButton(text="💬 ফিডব্যাক", callback_data="admin_feedback", style="primary"))
        builder.row(InlineKeyboardButton(text="📢 ব্রডকাস্ট", callback_data="admin_broadcast", style="primary"))
        builder.row(InlineKeyboardButton(text="🎁 প্রোমো কোড জেনারেট", callback_data="admin_promo", style="success"))
        builder.row(InlineKeyboardButton(text="📊 স্ট্যাটস", callback_data="admin_stats", style="primary"))
        builder.row(InlineKeyboardButton(text="🔗 অ্যাড লিংক", callback_data="admin_ads", style="primary"))
        builder.row(InlineKeyboardButton(text="⚙️ সেটিংস", callback_data="admin_settings", style="primary"))
        builder.row(InlineKeyboardButton(text="🏠 হোম", callback_data="home", style="primary"))
    else:
        builder.row(InlineKeyboardButton(text="👤 User Manage", callback_data="admin_user", style="primary"))
        builder.row(InlineKeyboardButton(text="🎬 Movie/Series Manage", callback_data="admin_movies", style="primary"))
        builder.row(InlineKeyboardButton(text="💳 Payment Setup", callback_data="admin_payment", style="primary"))
        builder.row(InlineKeyboardButton(text="📦 Subscription Plans", callback_data="admin_plans", style="primary"))
        builder.row(InlineKeyboardButton(text="🧾 Orders / Pending", callback_data="admin_orders", style="success"))
        builder.row(InlineKeyboardButton(text="📩 Movie Requests", callback_data="admin_requests", style="primary"))
        builder.row(InlineKeyboardButton(text="💬 Feedbacks", callback_data="admin_feedback", style="primary"))
        builder.row(InlineKeyboardButton(text="📢 Broadcast", callback_data="admin_broadcast", style="primary"))
        builder.row(InlineKeyboardButton(text="🎁 Generate Promo Code", callback_data="admin_promo", style="success"))
        builder.row(InlineKeyboardButton(text="📊 Stats", callback_data="admin_stats", style="primary"))
        builder.row(InlineKeyboardButton(text="🔗 Ad Links", callback_data="admin_ads", style="primary"))
        builder.row(InlineKeyboardButton(text="⚙️ Settings", callback_data="admin_settings", style="primary"))
        builder.row(InlineKeyboardButton(text="🏠 Home", callback_data="home", style="primary"))
    return builder.as_markup()


def admin_back_kb(lang: str = "bn") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    text = "⬅️ অ্যাডমিন প্যানেলে ফিরে যান" if lang == "bn" else "⬅️ Back to Admin Panel"
    builder.row(InlineKeyboardButton(text=text, callback_data="admin_panel", style="primary"))
    return builder.as_markup()
