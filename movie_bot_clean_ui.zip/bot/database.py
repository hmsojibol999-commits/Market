import aiosqlite
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path

DB_PATH = Path("data/bot.db")


async def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT,
            language TEXT DEFAULT 'bn',
            credits INTEGER DEFAULT 0,
            premium_until TEXT,
            referred_by INTEGER,
            total_referred INTEGER DEFAULT 0,
            is_blocked INTEGER DEFAULT 0,
            joined_at TEXT,
            last_daily_credit TEXT,
            last_promo_used TEXT
        );

        CREATE TABLE IF NOT EXISTS movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            normalized_title TEXT,
            year TEXT,
            runtime TEXT,
            imdb TEXT,
            audio TEXT,
            is_series INTEGER DEFAULT 0,
            total_episodes INTEGER DEFAULT 0,
            thumb_file_id TEXT,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS movie_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER,
            quality TEXT,          -- 720 or 1080
            file_id TEXT,
            episode INTEGER DEFAULT 0,  -- 0 for movie, 1+ for series
            caption TEXT,
            FOREIGN KEY (movie_id) REFERENCES movies(id)
        );

        CREATE TABLE IF NOT EXISTS promo_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            credits INTEGER,
            is_daily INTEGER DEFAULT 0,
            max_uses INTEGER DEFAULT 0,   -- 0 = unlimited users
            used_count INTEGER DEFAULT 0,
            created_at TEXT,
            expires_at TEXT,
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS promo_uses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT,
            user_id INTEGER,
            used_at TEXT,
            UNIQUE(code, user_id)
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            plan_name TEXT,
            amount TEXT,
            trx_id TEXT,
            status TEXT DEFAULT 'pending',  -- pending, approved, rejected
            created_at TEXT,
            processed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT,
            type TEXT,  -- movie / series
            status TEXT DEFAULT 'pending',
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS feedbacks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            message TEXT,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS wallets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            method TEXT,      -- bkash, nagad, rocket, binance
            number TEXT,
            extra TEXT,       -- for binance uid/address
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            days INTEGER,
            price INTEGER,
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS ad_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            url TEXT,
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS tools (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            file_id TEXT,
            file_type TEXT,
            created_at TEXT
        );
        """)
        await db.commit()

        # Default settings
        defaults = {
            "refer_reward": "3",
            "daily_credit": "1",
            "watch_expire_hours": "10",
            "force_join": "1"
        }
        for k, v in defaults.items():
            await db.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v)
            )
        await db.commit()


# -------------------- USERS --------------------

async def get_user(user_id: int) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = await cur.fetchone()
        return dict(row) if row else None


async def create_user(user_id: int, username: str, full_name: str, referred_by: int = None):
    async with aiosqlite.connect(DB_PATH) as db:
        now = datetime.utcnow().isoformat()
        await db.execute(
            """INSERT OR IGNORE INTO users 
               (user_id, username, full_name, joined_at, referred_by) 
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, username, full_name, now, referred_by)
        )
        if referred_by:
            await db.execute(
                "UPDATE users SET total_referred = total_referred + 1 WHERE user_id = ?",
                (referred_by,)
            )
            # Give refer reward
            cur = await db.execute("SELECT value FROM settings WHERE key = 'refer_reward'")
            row = await cur.fetchone()
            reward = int(row[0]) if row else 3
            await db.execute(
                "UPDATE users SET credits = credits + ? WHERE user_id = ?",
                (reward, referred_by)
            )
        await db.commit()


async def update_user(user_id: int, **kwargs):
    if not kwargs:
        return
    keys = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [user_id]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE users SET {keys} WHERE user_id = ?", values)
        await db.commit()


async def add_credits(user_id: int, amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET credits = credits + ? WHERE user_id = ?",
            (amount, user_id)
        )
        await db.commit()


async def deduct_credit(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT credits FROM users WHERE user_id = ?", (user_id,))
        row = await cur.fetchone()
        if not row or row[0] < 1:
            return False
        await db.execute(
            "UPDATE users SET credits = credits - 1 WHERE user_id = ?", (user_id,)
        )
        await db.commit()
        return True


async def is_premium(user_id: int) -> bool:
    user = await get_user(user_id)
    if not user or not user.get("premium_until"):
        return False
    try:
        until = datetime.fromisoformat(user["premium_until"])
        return until > datetime.utcnow()
    except:
        return False


async def give_daily_credit(user_id: int) -> bool:
    """Give automatic daily credit if 24h passed."""
    user = await get_user(user_id)
    if not user:
        return False
    now = datetime.utcnow()
    last = user.get("last_daily_credit")
    if last:
        try:
            last_dt = datetime.fromisoformat(last)
            if (now - last_dt) < timedelta(hours=24):
                return False
        except:
            pass
    await add_credits(user_id, 1)
    await update_user(user_id, last_daily_credit=now.isoformat())
    return True


# -------------------- PROMO CODES --------------------

async def create_promo_code(code: str, credits: int, is_daily: bool = False, max_uses: int = 0, hours_valid: int = 48):
    async with aiosqlite.connect(DB_PATH) as db:
        now = datetime.utcnow()
        expires = (now + timedelta(hours=hours_valid)).isoformat()
        await db.execute(
            """INSERT OR REPLACE INTO promo_codes 
               (code, credits, is_daily, max_uses, created_at, expires_at, is_active)
               VALUES (?, ?, ?, ?, ?, ?, 1)""",
            (code.upper(), credits, 1 if is_daily else 0, max_uses, now.isoformat(), expires)
        )
        await db.commit()


async def use_promo_code(user_id: int, code: str) -> tuple[bool, str]:
    code = code.upper().strip()
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM promo_codes WHERE code = ? AND is_active = 1", (code,)
        )
        promo = await cur.fetchone()
        if not promo:
            return False, "❌ অবৈধ বা মেয়াদোত্তীর্ণ কোড।"

        # Check expiry
        if promo["expires_at"]:
            try:
                if datetime.fromisoformat(promo["expires_at"]) < datetime.utcnow():
                    return False, "❌ এই কোডের মেয়াদ শেষ হয়ে গেছে।"
            except:
                pass

        # Check if user already used
        cur = await db.execute(
            "SELECT id FROM promo_uses WHERE code = ? AND user_id = ?", (code, user_id)
        )
        if await cur.fetchone():
            return False, "❌ আপনি এই কোডটি আগেই ব্যবহার করেছেন।"

        # Check max uses
        if promo["max_uses"] > 0 and promo["used_count"] >= promo["max_uses"]:
            return False, "❌ এই কোডের ব্যবহার সীমা শেষ।"

        # Apply
        await db.execute(
            "INSERT INTO promo_uses (code, user_id, used_at) VALUES (?, ?, ?)",
            (code, user_id, datetime.utcnow().isoformat())
        )
        await db.execute(
            "UPDATE promo_codes SET used_count = used_count + 1 WHERE code = ?", (code,)
        )
        await db.commit()

    await add_credits(user_id, promo["credits"])
    return True, f"✅ সফল! আপনি {promo['credits']} ক্রেডিট পেয়েছেন।"


# -------------------- MOVIES --------------------

async def find_movie(title: str, is_series: bool = False) -> Optional[Dict]:
    normalized = title.lower().strip()
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """SELECT * FROM movies 
               WHERE normalized_title LIKE ? AND is_series = ?
               ORDER BY id DESC LIMIT 1""",
            (f"%{normalized}%", 1 if is_series else 0)
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def get_movie_files(movie_id: int, quality: str = None, episode: int = None):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        query = "SELECT * FROM movie_files WHERE movie_id = ?"
        params = [movie_id]
        if quality:
            query += " AND quality = ?"
            params.append(quality)
        if episode is not None:
            query += " AND episode = ?"
            params.append(episode)
        cur = await db.execute(query, params)
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def save_movie_from_channel(title: str, quality: str, file_id: str, 
                                  is_series: bool = False, episode: int = 0,
                                  year: str = "", runtime: str = "", imdb: str = "",
                                  audio: str = "", thumb_file_id: str = None):
    normalized = title.lower().strip()
    async with aiosqlite.connect(DB_PATH) as db:
        # Find or create movie
        cur = await db.execute(
            "SELECT id FROM movies WHERE normalized_title = ? AND is_series = ?",
            (normalized, 1 if is_series else 0)
        )
        row = await cur.fetchone()
        if row:
            movie_id = row[0]
            if thumb_file_id:
                await db.execute(
                    "UPDATE movies SET thumb_file_id = ? WHERE id = ?",
                    (thumb_file_id, movie_id)
                )
        else:
            cur = await db.execute(
                """INSERT INTO movies 
                   (title, normalized_title, year, runtime, imdb, audio, is_series, total_episodes, thumb_file_id, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (title, normalized, year, runtime, imdb, audio, 1 if is_series else 0,
                 episode if is_series else 0, thumb_file_id, datetime.utcnow().isoformat())
            )
            movie_id = cur.lastrowid

        # Update total episodes if series
        if is_series and episode > 0:
            await db.execute(
                "UPDATE movies SET total_episodes = MAX(total_episodes, ?) WHERE id = ?",
                (episode, movie_id)
            )

        # Save file
        await db.execute(
            """INSERT INTO movie_files (movie_id, quality, file_id, episode)
               VALUES (?, ?, ?, ?)""",
            (movie_id, quality, file_id, episode)
        )
        await db.commit()
        return movie_id


# -------------------- SETTINGS / PLANS / WALLETS --------------------

async def get_setting(key: str, default: str = "") -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cur.fetchone()
        return row[0] if row else default


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value)
        )
        await db.commit()


async def get_plans() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM plans WHERE is_active = 1 ORDER BY days")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def get_wallets() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM wallets WHERE is_active = 1")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# -------------------- ORDERS / REQUESTS / FEEDBACK --------------------

async def create_order(user_id: int, plan_name: str, amount: str, trx_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO orders (user_id, plan_name, amount, trx_id, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, plan_name, amount, trx_id, datetime.utcnow().isoformat())
        )
        await db.commit()


async def get_pending_orders() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM orders WHERE status = 'pending' ORDER BY id DESC"
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def update_order_status(order_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET status = ?, processed_at = ? WHERE id = ?",
            (status, datetime.utcnow().isoformat(), order_id)
        )
        await db.commit()


async def add_request(user_id: int, title: str, type_: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO requests (user_id, title, type, created_at) VALUES (?, ?, ?, ?)",
            (user_id, title, type_, datetime.utcnow().isoformat())
        )
        await db.commit()


async def add_feedback(user_id: int, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO feedbacks (user_id, message, created_at) VALUES (?, ?, ?)",
            (user_id, message, datetime.utcnow().isoformat())
        )
        await db.commit()


# -------------------- STATS --------------------

async def get_stats() -> Dict[str, Any]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM users")
        total_users = (await cur.fetchone())[0]

        cur = await db.execute(
            "SELECT COUNT(*) FROM users WHERE premium_until IS NOT NULL AND premium_until > ?",
            (datetime.utcnow().isoformat(),)
        )
        premium_users = (await cur.fetchone())[0]

        cur = await db.execute(
            "SELECT COUNT(*) FROM orders WHERE status = 'approved'"
        )
        total_orders = (await cur.fetchone())[0]

        # Simple income calculation (sum of approved amounts if numeric)
        cur = await db.execute(
            "SELECT amount FROM orders WHERE status = 'approved'"
        )
        amounts = await cur.fetchall()
        total_income = 0
        for a in amounts:
            try:
                total_income += int("".join(filter(str.isdigit, str(a[0]))))
            except:
                pass

        return {
            "total_users": total_users,
            "premium_users": premium_users,
            "total_orders": total_orders,
            "total_income": total_income
        }
