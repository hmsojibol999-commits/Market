from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import random
import string

from config import settings
from database import (
    get_user, get_stats, create_promo_code, get_pending_orders,
    update_order_status, add_credits, update_user, is_premium
)
from keyboards.admin import admin_panel_kb, admin_back_kb
from keyboards.common import cancel_kb
from utils.texts import t

router = Router()


class AdminStates(StatesGroup):
    waiting_promo_credits = State()
    waiting_user_id = State()
    waiting_broadcast = State()


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


@router.callback_query(F.data == "admin_panel")
async def admin_panel(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await callback.message.edit_text(
        "⚙️ <b>Admin Panel</b>\n\nChoose an option:",
        reply_markup=admin_panel_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    stats = await get_stats()
    text = (
        f"📊 <b>Bot Statistics</b>\n\n"
        f"👥 Total Users: <b>{stats['total_users']}</b>\n"
        f"💎 Premium Users: <b>{stats['premium_users']}</b>\n"
        f"✅ Approved Orders: <b>{stats['total_orders']}</b>\n"
        f"💰 Total Income (approx): <b>{stats['total_income']} ৳</b>"
    )
    await callback.message.edit_text(text, reply_markup=admin_back_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin_promo")
async def admin_promo_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_promo_credits)
    await callback.message.edit_text(
        "🎁 কত ক্রেডিট দিবেন এই প্রোমো কোডে?\n\nসংখ্যা লিখুন (উদাহরণ: 1 বা 5):",
        reply_markup=cancel_kb("bn")
    )
    await callback.answer()


@router.message(AdminStates.waiting_promo_credits)
async def admin_promo_generate(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        credits = int(message.text.strip())
        if credits < 1 or credits > 100:
            await message.answer("১ থেকে ১০০ এর মধ্যে দিন।")
            return
    except:
        await message.answer("সঠিক সংখ্যা লিখুন।")
        return

    # Generate random code
    code = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    await create_promo_code(code, credits, is_daily=False, max_uses=0, hours_valid=72)

    await message.answer(
        f"✅ প্রোমো কোড তৈরি হয়েছে!\n\n"
        f"কোড: <code>{code}</code>\n"
        f"ক্রেডিট: <b>{credits}</b>\n\n"
        f"এই কোডটি আপনার চ্যানেলে পোস্ট করুন।\n"
        f"ইউজাররা বটে গিয়ে <b>🎁 প্রোমো কোড</b> বাটনে ক্লিক করে কোডটি দিলে ক্রেডিট পাবে।",
        parse_mode="HTML"
    )
    await state.clear()


@router.callback_query(F.data == "admin_orders")
async def admin_orders(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    orders = await get_pending_orders()
    if not orders:
        await callback.message.edit_text("কোনো পেন্ডিং অর্ডার নেই।", reply_markup=admin_back_kb())
        await callback.answer()
        return

    text = "🧾 <b>Pending Orders</b>\n\n"
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for o in orders[:15]:
        text += (
            f"#{o['id']} | User: <code>{o['user_id']}</code>\n"
            f"Plan: {o['plan_name']} | {o['amount']}৳\n"
            f"Trx: <code>{o['trx_id']}</code>\n"
            f"Time: {o['created_at'][:16]}\n\n"
        )
        builder.row(
            InlineKeyboardButton(text=f"✅ Approve #{o['id']}", callback_data=f"approve_{o['id']}", style="success"),
            InlineKeyboardButton(text=f"❌ Reject #{o['id']}", callback_data=f"reject_{o['id']}", style="danger")
        )
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="admin_panel", style="primary"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("approve_"))
async def approve_order(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    order_id = int(callback.data.split("_")[1])
    from database import get_pending_orders
    orders = await get_pending_orders()
    order = next((o for o in orders if o["id"] == order_id), None)
    if not order:
        await callback.answer("Order not found", show_alert=True)
        return

    await update_order_status(order_id, "approved")

    # Activate premium (simple: 30 days default, improve later with plan days)
    from datetime import datetime, timedelta
    until = (datetime.utcnow() + timedelta(days=30)).isoformat()
    await update_user(order["user_id"], premium_until=until)

    try:
        await callback.bot.send_message(
            order["user_id"],
            f"✅ আপনার পেমেন্ট অ্যাপ্রুভ হয়েছে!\nপ্রিমিয়াম অ্যাকটিভ করা হয়েছে।"
        )
    except:
        pass

    await callback.answer("Approved!", show_alert=True)
    await admin_orders(callback)


@router.callback_query(F.data.startswith("reject_"))
async def reject_order(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    order_id = int(callback.data.split("_")[1])
    await update_order_status(order_id, "rejected")
    await callback.answer("Rejected", show_alert=True)
    await admin_orders(callback)


@router.callback_query(F.data == "admin_user")
async def admin_user_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_user_id)
    await callback.message.edit_text(
        "ইউজার আইডি বা ইউজারনেম লিখুন:",
        reply_markup=cancel_kb("bn")
    )
    await callback.answer()


@router.message(AdminStates.waiting_user_id)
async def admin_user_process(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    query = message.text.strip().lstrip("@")
    user = None
    if query.isdigit():
        user = await get_user(int(query))
    # Simple search by username not fully implemented for brevity

    if not user:
        await message.answer("ইউজার পাওয়া যায়নি।")
        return

    premium = "Yes" if await is_premium(user["user_id"]) else "No"
    text = (
        f"👤 <b>User Info</b>\n\n"
        f"ID: <code>{user['user_id']}</code>\n"
        f"Name: {user.get('full_name')}\n"
        f"Username: @{user.get('username')}\n"
        f"Credits: {user.get('credits', 0)}\n"
        f"Premium: {premium}\n"
        f"Referred: {user.get('total_referred', 0)}\n"
        f"Blocked: {'Yes' if user.get('is_blocked') else 'No'}"
    )
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="+5 Credit", callback_data=f"addcred_{user['user_id']}_5", style="success"),
        InlineKeyboardButton(text="+10 Credit", callback_data=f"addcred_{user['user_id']}_10", style="success")
    )
    builder.row(
        InlineKeyboardButton(text="Block", callback_data=f"block_{user['user_id']}", style="danger"),
        InlineKeyboardButton(text="Unblock", callback_data=f"unblock_{user['user_id']}", style="primary")
    )
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="admin_panel", style="primary"))
    await message.answer(text, reply_markup=builder.as_markup(), parse_mode="HTML")
    await state.clear()


@router.callback_query(F.data.startswith("addcred_"))
async def add_credit_admin(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split("_")
    uid = int(parts[1])
    amount = int(parts[2])
    await add_credits(uid, amount)
    await callback.answer(f"+{amount} credits added", show_alert=True)


@router.callback_query(F.data.startswith("block_"))
async def block_user(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split("_")[1])
    await update_user(uid, is_blocked=1)
    await callback.answer("User blocked", show_alert=True)


@router.callback_query(F.data.startswith("unblock_"))
async def unblock_user(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split("_")[1])
    await update_user(uid, is_blocked=0)
    await callback.answer("User unblocked", show_alert=True)
