from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, ChatMemberUpdated
from aiogram.filters import CommandStart, CommandObject
from aiogram.fsm.context import FSMContext

from config import settings
from database import get_user, create_user, give_daily_credit
from keyboards.common import language_kb
from keyboards.main_menu import main_menu_kb, force_join_kb
from utils.texts import t

router = Router()


async def check_subscription(bot: Bot, user_id: int) -> bool:
    """Check if user joined both required channels."""
    try:
        for ch_id in [settings.UPDATE_CHANNEL_ID, settings.BACKUP_CHANNEL_ID]:
            if not ch_id:
                continue
            member = await bot.get_chat_member(ch_id, user_id)
            if member.status in ("left", "kicked"):
                return False
        return True
    except Exception:
        return False


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, bot: Bot, command: CommandObject):
    await state.clear()
    user_id = message.from_user.id
    username = message.from_user.username or ""
    full_name = message.from_user.full_name or ""

    # Refer system
    referred_by = None
    if command.args and command.args.isdigit():
        ref_id = int(command.args)
        if ref_id != user_id:
            referred_by = ref_id

    user = await get_user(user_id)
    if not user:
        await create_user(user_id, username, full_name, referred_by)

    # Give daily credit if eligible
    await give_daily_credit(user_id)

    user = await get_user(user_id)
    lang = user.get("language", "bn") if user else "bn"

    # First time or language not set properly → ask language
    if not user or not user.get("language"):
        await message.answer(t("choose_lang", "bn"), reply_markup=language_kb())
        return

    # Force join check
    if not await check_subscription(bot, user_id):
        await message.answer(
            t("force_join", lang),
            reply_markup=force_join_kb(settings.UPDATE_CHANNEL_LINK, settings.BACKUP_CHANNEL_LINK, lang),
            parse_mode="HTML"
        )
        return

    is_admin = user_id in settings.admin_ids
    await message.answer(
        t("main_menu", lang),
        reply_markup=main_menu_kb(is_admin, lang),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("lang_"))
async def set_language(callback: CallbackQuery, state: FSMContext, bot: Bot):
    lang = callback.data.split("_")[1]  # bn or en
    user_id = callback.from_user.id
    from database import update_user
    await update_user(user_id, language=lang)

    await callback.message.edit_text(t("welcome", lang), parse_mode="HTML")

    # Force join
    if not await check_subscription(bot, user_id):
        await callback.message.answer(
            t("force_join", lang),
            reply_markup=force_join_kb(settings.UPDATE_CHANNEL_LINK, settings.BACKUP_CHANNEL_LINK, lang),
            parse_mode="HTML"
        )
    else:
        is_admin = user_id in settings.admin_ids
        await callback.message.answer(
            t("main_menu", lang),
            reply_markup=main_menu_kb(is_admin, lang),
            parse_mode="HTML"
        )
    await callback.answer()


@router.callback_query(F.data == "check_join")
async def check_join_callback(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    user = await get_user(user_id)
    lang = user.get("language", "bn") if user else "bn"

    if await check_subscription(bot, user_id):
        is_admin = user_id in settings.admin_ids
        await callback.message.edit_text(
            t("main_menu", lang),
            reply_markup=main_menu_kb(is_admin, lang),
            parse_mode="HTML"
        )
    else:
        await callback.answer(t("not_joined", lang), show_alert=True)
    await callback.answer()


@router.callback_query(F.data == "home")
async def go_home(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    is_admin = callback.from_user.id in settings.admin_ids
    await callback.message.edit_text(
        t("main_menu", lang),
        reply_markup=main_menu_kb(is_admin, lang),
        parse_mode="HTML"
    )
    await callback.answer()
