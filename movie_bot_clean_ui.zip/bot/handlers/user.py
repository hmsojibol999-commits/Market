from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from config import settings
from database import (
    get_user, is_premium, use_promo_code, add_feedback,
    get_plans, get_wallets, create_order, get_stats
)
from keyboards.main_menu import main_menu_kb
from keyboards.common import back_home_kb, cancel_kb
from utils.texts import t

router = Router()


class PromoState(StatesGroup):
    waiting_code = State()


class FeedbackState(StatesGroup):
    waiting_text = State()


class PaymentState(StatesGroup):
    waiting_trx = State()


@router.callback_query(F.data == "profile")
async def profile_handler(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    premium = "✅ Active" if await is_premium(callback.from_user.id) else "❌ No"
    if lang == "bn":
        premium = "✅ চালু" if await is_premium(callback.from_user.id) else "❌ নেই"

    text = t("profile", lang,
             user_id=user["user_id"],
             credits=user.get("credits", 0),
             premium=premium,
             referred=user.get("total_referred", 0))
    await callback.message.edit_text(text, reply_markup=back_home_kb(lang), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "promo_code")
async def promo_start(callback: CallbackQuery, state: FSMContext):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await state.set_state(PromoState.waiting_code)
    await callback.message.edit_text(
        t("promo_prompt", lang),
        reply_markup=cancel_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(PromoState.waiting_code)
async def promo_process(message: Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    code = message.text.strip()
    success, msg = await use_promo_code(message.from_user.id, code)
    await message.answer(msg, parse_mode="HTML")
    await state.clear()
    is_admin = message.from_user.id in settings.admin_ids
    await message.answer(t("main_menu", lang), reply_markup=main_menu_kb(is_admin, lang), parse_mode="HTML")


@router.callback_query(F.data == "refer")
async def refer_handler(callback: CallbackQuery, bot: Bot):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start={callback.from_user.id}"
    if lang == "bn":
        text = (
            f"🔗 <b>আপনার রেফার লিংক</b>\n\n"
            f"<code>{link}</code>\n\n"
            f"একজন রেফার করলে আপনি <b>৩ ক্রেডিট</b> পাবেন।\n"
            f"মোট রেফার: <b>{user.get('total_referred', 0)}</b>"
        )
    else:
        text = (
            f"🔗 <b>Your Refer Link</b>\n\n"
            f"<code>{link}</code>\n\n"
            f"You get <b>3 credits</b> per successful refer.\n"
            f"Total referred: <b>{user.get('total_referred', 0)}</b>"
        )
    await callback.message.edit_text(text, reply_markup=back_home_kb(lang), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "premium")
async def premium_handler(callback: CallbackQuery, state: FSMContext):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    plans = await get_plans()
    wallets = await get_wallets()

    if not plans:
        text = "❌ এখন কোনো প্ল্যান নেই।" if lang == "bn" else "❌ No plans available now."
        await callback.message.edit_text(text, reply_markup=back_home_kb(lang))
        await callback.answer()
        return

    text = "💎 <b>প্রিমিয়াম প্ল্যান</b>\n\n" if lang == "bn" else "💎 <b>Premium Plans</b>\n\n"
    for p in plans:
        text += f"• <b>{p['name']}</b> — {p['days']} দিন — <b>{p['price']} টাকা</b>\n"

    text += "\n" + ("নিচের ওয়ালেটে টাকা পাঠিয়ে ট্রানজেকশন আইডি পাঠান:" if lang == "bn" else "Send money to the wallets below and submit Transaction ID:")

    if wallets:
        text += "\n\n"
        for w in wallets:
            text += f"<b>{w['method'].upper()}</b>: <code>{w['number']}</code>\n"
            if w.get("extra"):
                text += f"Extra: <code>{w['extra']}</code>\n"

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for p in plans:
        builder.row(InlineKeyboardButton(
            text=f"{p['name']} - {p['price']}৳",
            callback_data=f"buy_plan_{p['id']}",
            style="success"
        ))
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="home", style="primary"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("buy_plan_"))
async def buy_plan(callback: CallbackQuery, state: FSMContext):
    plan_id = int(callback.data.split("_")[-1])
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await state.set_state(PaymentState.waiting_trx)
    await state.update_data(plan_id=plan_id)
    text = "ট্রানজেকশন আইডি পাঠান:" if lang == "bn" else "Send the Transaction ID:"
    await callback.message.edit_text(text, reply_markup=cancel_kb(lang))
    await callback.answer()


@router.message(PaymentState.waiting_trx)
async def process_trx(message: Message, state: FSMContext):
    data = await state.get_data()
    plan_id = data.get("plan_id")
    user = await get_user(message.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    trx = message.text.strip()

    plans = await get_plans()
    plan = next((p for p in plans if p["id"] == plan_id), None)
    if not plan:
        await message.answer("Plan not found.")
        await state.clear()
        return

    await create_order(message.from_user.id, plan["name"], str(plan["price"]), trx)

    # Notify admins
    for admin_id in settings.admin_ids:
        try:
            await message.bot.send_message(
                admin_id,
                f"🧾 নতুন পেমেন্ট রিকোয়েস্ট\n\n"
                f"User: {message.from_user.id}\n"
                f"Plan: {plan['name']}\n"
                f"Amount: {plan['price']}\n"
                f"Trx: <code>{trx}</code>",
                parse_mode="HTML"
            )
        except:
            pass

    msg = "✅ আপনার রিকোয়েস্ট গ্রহণ করা হয়েছে। অ্যাডমিন চেক করে অ্যাপ্রুভ করবে।" if lang == "bn" else "✅ Request received. Admin will approve soon."
    await message.answer(msg)
    await state.clear()
    is_admin = message.from_user.id in settings.admin_ids
    await message.answer(t("main_menu", lang), reply_markup=main_menu_kb(is_admin, lang), parse_mode="HTML")


@router.callback_query(F.data == "support")
async def support_handler(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await callback.message.edit_text(
        t("support_note", lang),
        reply_markup=back_home_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "feedback")
async def feedback_start(callback: CallbackQuery, state: FSMContext):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await state.set_state(FeedbackState.waiting_text)
    await callback.message.edit_text(
        t("feedback_prompt", lang),
        reply_markup=cancel_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(FeedbackState.waiting_text)
async def feedback_process(message: Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await add_feedback(message.from_user.id, message.text)
    await message.answer(t("feedback_thanks", lang))
    await state.clear()
    is_admin = message.from_user.id in settings.admin_ids
    await message.answer(t("main_menu", lang), reply_markup=main_menu_kb(is_admin, lang), parse_mode="HTML")


@router.callback_query(F.data == "earn_credit")
async def earn_credit_handler(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    # For now closed until admin adds links
    await callback.message.edit_text(
        t("earn_closed", lang),
        reply_markup=back_home_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "cancel")
async def cancel_handler(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    is_admin = callback.from_user.id in settings.admin_ids
    await callback.message.edit_text(
        t("main_menu", lang),
        reply_markup=main_menu_kb(is_admin, lang),
        parse_mode="HTML"
    )
    await callback.answer()
