from aiogram import Router, F, Bot
from aiogram.types import Message
from config import settings
from database import save_movie_from_channel
import re

router = Router()


def parse_caption(caption: str) -> dict:
    """Extract title, quality, episode, year etc from caption."""
    if not caption:
        return {}
    data = {"title": "", "quality": None, "episode": 0, "year": "", "runtime": "", "imdb": "", "audio": ""}

    # Quality
    if "#720" in caption:
        data["quality"] = "720"
    elif "#1080" in caption:
        data["quality"] = "1080"

    # Episode
    ep_match = re.search(r"(?:EP|Episode|E)\s*[#:]?\s*(\d+)", caption, re.IGNORECASE)
    if ep_match:
        data["episode"] = int(ep_match.group(1))

    # Clean title (remove hashtags and common tags)
    title = caption
    for tag in ["#720", "#1080", "#thumbnail", "#broadcast", "#tools"]:
        title = title.replace(tag, "")
    title = re.sub(r"(?:EP|Episode|E)\s*[#:]?\s*\d+", "", title, flags=re.IGNORECASE)
    title = re.sub(r"\s+", " ", title).strip()
    # Take first line as title
    data["title"] = title.split("\n")[0].strip()[:100]

    return data


@router.channel_post(F.chat.id == settings.SECRET_CHANNEL_ID)
async def secret_channel_handler(message: Message, bot: Bot):
    caption = message.caption or message.text or ""

    # Broadcast
    if "#broadcast" in caption.lower():
        # Forward to all users would be heavy; for now just log or implement carefully
        # Simple: notify admins only or implement later
        return

    # Tools
    if "#tools" in caption.lower() and (message.document or message.video):
        # Save tool (simplified)
        return

    # Thumbnail
    if message.photo and "#thumbnail" in caption.lower():
        data = parse_caption(caption)
        if data["title"]:
            # We need to attach thumb to existing movie later or update
            # For simplicity, we can store and match by title
            pass
        return

    # Video files
    if message.video or message.document:
        data = parse_caption(caption)
        if not data.get("quality") or not data.get("title"):
            return

        file_id = message.video.file_id if message.video else message.document.file_id
        is_series = data["episode"] > 0

        await save_movie_from_channel(
            title=data["title"],
            quality=data["quality"],
            file_id=file_id,
            is_series=is_series,
            episode=data["episode"],
            year=data.get("year", ""),
            runtime=data.get("runtime", ""),
            imdb=data.get("imdb", ""),
            audio=data.get("audio", "")
        )
