from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from config import settings
from database import (
    get_user, find_movie, get_movie_files, is_premium,
    deduct_credit, add_request
)
from keyboards.main_menu import (
    search_type_kb, movie_result_kb, series_episodes_kb, main_menu_kb
)
from keyboards.common import back_home_kb, cancel_kb
from utils.texts import t

router = Router()


class SearchState(StatesGroup):
    waiting_movie = State()
    waiting_series = State()


@router.callback_query(F.data == "search")
async def search_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await callback.message.edit_text(
        t("search_prompt", lang),
        reply_markup=search_type_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "search_movie")
async def search_movie_start(callback: CallbackQuery, state: FSMContext):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await state.set_state(SearchState.waiting_movie)
    await callback.message.edit_text(
        t("search_movie_prompt", lang),
        reply_markup=cancel_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "search_series")
async def search_series_start(callback: CallbackQuery, state: FSMContext):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await state.set_state(SearchState.waiting_series)
    await callback.message.edit_text(
        t("search_series_prompt", lang),
        reply_markup=cancel_kb(lang),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(SearchState.waiting_movie)
async def process_movie_search(message: Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    title = message.text.strip()
    movie = await find_movie(title, is_series=False)

    if not movie:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        from aiogram.types import InlineKeyboardButton
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(
            text="📩 Request this Movie" if lang == "en" else "📩 এই মুভি রিকোয়েস্ট করুন",
            callback_data=f"req_movie_{title[:60]}",
            style="primary"
        ))
        builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="search", style="primary"))
        await message.answer(t("not_found", lang), reply_markup=builder.as_markup(), parse_mode="HTML")
        await state.clear()
        return

    # Build nice info box
    premium = await is_premium(message.from_user.id)
    has_credit = user.get("credits", 0) > 0

    info = (
        f"🎬 <b>{movie['title']}</b>\n\n"
        f"📅 Year: {movie.get('year') or 'N/A'}\n"
        f"⏱ Runtime: {movie.get('runtime') or 'N/A'}\n"
        f"⭐ IMDb: {movie.get('imdb') or 'N/A'}\n"
        f"🎧 Audio: {movie.get('audio') or 'N/A'}\n"
        f"✅ Available"
    )

    # Send poster if available
    if movie.get("thumb_file_id"):
        await message.answer_photo(
            movie["thumb_file_id"],
            caption=info,
            reply_markup=movie_result_kb(movie["id"], premium, has_credit, lang),
            parse_mode="HTML"
        )
    else:
        await message.answer(
            info,
            reply_markup=movie_result_kb(movie["id"], premium, has_credit, lang),
            parse_mode="HTML"
        )
    await state.clear()


@router.message(SearchState.waiting_series)
async def process_series_search(message: Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    title = message.text.strip()
    series = await find_movie(title, is_series=True)

    if not series:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        from aiogram.types import InlineKeyboardButton
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(
            text="📩 Request this Series" if lang == "en" else "📩 এই সিরিজ রিকোয়েস্ট করুন",
            callback_data=f"req_series_{title[:60]}",
            style="primary"
        ))
        builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="search", style="primary"))
        await message.answer(t("not_found", lang), reply_markup=builder.as_markup(), parse_mode="HTML")
        await state.clear()
        return

    premium = await is_premium(message.from_user.id)
    total = series.get("total_episodes") or 1

    info = (
        f"📺 <b>{series['title']}</b>\n\n"
        f"📅 Year: {series.get('year') or 'N/A'}\n"
        f"⭐ IMDb: {series.get('imdb') or 'N/A'}\n"
        f"🎧 Audio: {series.get('audio') or 'N/A'}\n"
        f"🎞 Total Episodes: <b>{total}</b>\n"
        f"✅ Available\n\n"
        f"নিচ থেকে এপিসোড বেছে নিন:" if lang == "bn" else "Select episode below:"
    )

    if series.get("thumb_file_id"):
        await message.answer_photo(
            series["thumb_file_id"],
            caption=info,
            reply_markup=series_episodes_kb(series["id"], total, premium, lang),
            parse_mode="HTML"
        )
    else:
        await message.answer(
            info,
            reply_markup=series_episodes_kb(series["id"], total, premium, lang),
            parse_mode="HTML"
        )
    await state.clear()


@router.callback_query(F.data.startswith("req_"))
async def request_content(callback: CallbackQuery):
    parts = callback.data.split("_", 2)
    type_ = parts[1]  # movie / series
    title = parts[2]
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    await add_request(callback.from_user.id, title, type_)
    await callback.answer(t("request_sent", lang), show_alert=True)
    await callback.message.edit_reply_markup(reply_markup=None)


@router.callback_query(F.data.startswith("watch_"))
async def watch_handler(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    premium = await is_premium(callback.from_user.id)

    parts = callback.data.split("_")
    # watch_{id}_720  or  watch_ep_{id}_{ep}
    if parts[1] == "ep":
        movie_id = int(parts[2])
        episode = int(parts[3])
        quality = "1080" if premium else "720"
    else:
        movie_id = int(parts[1])
        quality = parts[2]
        episode = 0

    if not premium:
        # Need credit
        success = await deduct_credit(callback.from_user.id)
        if not success:
            await callback.answer(t("no_credit", lang), show_alert=True)
            return

    files = await get_movie_files(movie_id, quality=quality, episode=episode if episode else None)
    if not files:
        # Fallback to other quality
        files = await get_movie_files(movie_id, episode=episode if episode else None)

    if not files:
        await callback.answer("File not found.", show_alert=True)
        return

    file_id = files[0]["file_id"]
    await callback.message.answer_video(
        file_id,
        caption=t("watch_expire", lang),
        protect_content=not premium  # free users cannot forward
    )
    await callback.answer()


@router.callback_query(F.data.startswith("download_"))
async def download_handler(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    lang = user.get("language", "bn") if user else "bn"
    premium = await is_premium(callback.from_user.id)
    if not premium:
        await callback.answer("Only for Premium users.", show_alert=True)
        return

    parts = callback.data.split("_")
    movie_id = int(parts[1])
    quality = parts[2]

    files = await get_movie_files(movie_id, quality=quality)
    if not files:
        await callback.answer("File not found.", show_alert=True)
        return

    file_id = files[0]["file_id"]
    # For download we just send the file again (user can save)
    await callback.message.answer_document(file_id, caption="📥 Download ready")
    await callback.answer()
