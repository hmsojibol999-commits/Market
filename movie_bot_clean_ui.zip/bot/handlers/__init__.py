from aiogram import Router

from .start import router as start_router
from .user import router as user_router
from .search import router as search_router
from .admin import router as admin_router
from .channel import router as channel_router


def setup_routers() -> Router:
    router = Router()
    router.include_router(start_router)
    router.include_router(user_router)
    router.include_router(search_router)
    router.include_router(admin_router)
    router.include_router(channel_router)
    return router
