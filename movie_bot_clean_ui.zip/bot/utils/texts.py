TEXTS = {
    "bn": {
        "welcome": (
            "🌟 <b>স্বাগতম!</b>\n\n"
            "এই বটের মাধ্যমে আপনি খুব সহজেই আপনার পছন্দের মুভি ও অ্যানিমেশন দেখতে পারবেন।\n"
            "আর কোনো ওয়েবসাইটে ঘুরে সময় নষ্ট করতে হবে না।\n\n"
            "আমরা সততা ও আপনার বিশ্বাসকে গুরুত্ব দিই।"
        ),
        "choose_lang": "🌐 আপনার ভাষা বেছে নিন:",
        "force_join": (
            "⚠️ <b>বট ব্যবহার করার আগে অবশ্যই নিচের দুটি চ্যানেল জয়েন করুন</b>\n\n"
            "১. আপডেট চ্যানেল — নতুন মুভি ও প্রমোশনের জন্য\n"
            "২. ব্যাকআপ চ্যানেল — কোনো সমস্যা হলে নতুন লিংক এখানে দেওয়া হবে\n\n"
            "জয়েন করার পর নিচের বাটনে ক্লিক করুন।"
        ),
        "not_joined": "❌ আপনি এখনো দুটি চ্যানেল জয়েন করেননি। দয়া করে জয়েন করে আবার চেষ্টা করুন।",
        "main_menu": "🏠 <b>মেইন মেনু</b>\n\nনিচ থেকে আপনার পছন্দের অপশন বেছে নিন:",
        "search_prompt": "🔍 আপনি কী খুঁজতে চান?",
        "search_movie_prompt": (
            "🎬 <b>মুভির নাম লিখুন</b>\n\n"
            "সঠিক ইংরেজি বানানে লিখুন।\n"
            "বানান ভুল হলে খুঁজে নাও পেতে পারে।"
        ),
        "search_series_prompt": (
            "📺 <b>সিরিজের নাম লিখুন</b>\n\n"
            "সঠিক ইংরেজি বানানে লিখুন।"
        ),
        "not_found": "❌ দুঃখিত, এই নামে কিছু পাওয়া যায়নি।\n\nআপনি রিকোয়েস্ট করতে পারেন।",
        "request_sent": "✅ আপনার রিকোয়েস্ট গ্রহণ করা হয়েছে। আপলোড হলে নোটিফিকেশন পাবেন।",
        "no_credit": (
            "⚠️ আপনার ক্রেডিট শেষ হয়ে গেছে।\n\n"
            "💎 প্রিমিয়াম নিলে আনলিমিটেড দেখতে পারবেন।\n"
            "অথবা প্রোমো কোড ব্যবহার করে ক্রেডিট আনলক করুন।"
        ),
        "watch_expire": "⏳ এই ভিডিওটি ১০ ঘণ্টা পর অটোমেটিক মুছে যাবে। সময়মতো দেখে নিন।",
        "profile": (
            "👤 <b>আপনার প্রোফাইল</b>\n\n"
            "🆔 আইডি: <code>{user_id}</code>\n"
            "💰 ক্রেডিট: <b>{credits}</b>\n"
            "💎 প্রিমিয়াম: {premium}\n"
            "👥 রেফার: {referred}"
        ),
        "promo_prompt": "🎁 প্রোমো কোডটি লিখুন:",
        "earn_closed": "🔒 এই অপশনটি বর্তমানে বন্ধ আছে। অ্যাডমিন চালু করলে আপনারা ব্যবহার করতে পারবেন।",
        "support_note": (
            "💬 <b>সাপোর্ট</b>\n\n"
            "শুধুমাত্র পেমেন্ট সংক্রান্ত সমস্যার জন্য যোগাযোগ করুন।\n"
            "অন্য কোনো বিষয়ে রিপ্লাই দেওয়া হবে না।"
        ),
        "feedback_prompt": (
            "📝 <b>ফিডব্যাক</b>\n\n"
            "বটের কোনো বাগ, সমস্যা বা নতুন ফিচারের সাজেশন থাকলে লিখুন।\n"
            "আপনার মতামত আমাদের জন্য খুবই গুরুত্বপূর্ণ।"
        ),
        "feedback_thanks": "✅ ধন্যবাদ! আপনার ফিডব্যাক গ্রহণ করা হয়েছে।",
    },
    "en": {
        "welcome": (
            "🌟 <b>Welcome!</b>\n\n"
            "With this bot you can easily watch your favorite movies and animations.\n"
            "No more wasting time roaming different websites.\n\n"
            "We value honesty and your trust."
        ),
        "choose_lang": "🌐 Choose your language:",
        "force_join": (
            "⚠️ <b>Please join both channels before using the bot</b>\n\n"
            "1. Update Channel — for new movies & promotions\n"
            "2. Backup Channel — new links will be posted here if needed\n\n"
            "After joining, click the button below."
        ),
        "not_joined": "❌ You haven't joined both channels yet. Please join and try again.",
        "main_menu": "🏠 <b>Main Menu</b>\n\nChoose an option below:",
        "search_prompt": "🔍 What do you want to search?",
        "search_movie_prompt": (
            "🎬 <b>Enter Movie Name</b>\n\n"
            "Please write in correct English spelling.\n"
            "Wrong spelling may fail the search."
        ),
        "search_series_prompt": (
            "📺 <b>Enter Series Name</b>\n\n"
            "Please write in correct English spelling."
        ),
        "not_found": "❌ Sorry, nothing found with this name.\n\nYou can request it.",
        "request_sent": "✅ Your request has been received. You will get notification after upload.",
        "no_credit": (
            "⚠️ You have no credits left.\n\n"
            "💎 Get Premium for unlimited access.\n"
            "Or unlock credits with a Promo Code."
        ),
        "watch_expire": "⏳ This video will automatically expire after 10 hours. Watch in time.",
        "profile": (
            "👤 <b>Your Profile</b>\n\n"
            "🆔 ID: <code>{user_id}</code>\n"
            "💰 Credits: <b>{credits}</b>\n"
            "💎 Premium: {premium}\n"
            "👥 Referred: {referred}"
        ),
        "promo_prompt": "🎁 Enter the Promo Code:",
        "earn_closed": "🔒 This option is currently closed. It will be available after admin enables it.",
        "support_note": (
            "💬 <b>Support</b>\n\n"
            "Contact only for payment related issues.\n"
            "No reply for other topics."
        ),
        "feedback_prompt": (
            "📝 <b>Feedback</b>\n\n"
            "Write any bug, issue or feature suggestion.\n"
            "Your opinion is very important to us."
        ),
        "feedback_thanks": "✅ Thank you! Your feedback has been received.",
    }
}


def t(key: str, lang: str = "bn", **kwargs) -> str:
    text = TEXTS.get(lang, TEXTS["bn"]).get(key, key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except:
            return text
    return text
