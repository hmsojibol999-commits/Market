import os
from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    BOT_TOKEN: str
    ADMIN_IDS: str = ""  # comma separated
    SECRET_CHANNEL_ID: int = 0
    UPDATE_CHANNEL_ID: int = 0
    BACKUP_CHANNEL_ID: int = 0
    UPDATE_CHANNEL_LINK: str = "https://t.me/+YOUR_UPDATE_LINK"
    BACKUP_CHANNEL_LINK: str = "https://t.me/+YOUR_BACKUP_LINK"
    DATABASE_URL: str = "sqlite+aiosqlite:///data/bot.db"
    PORT: int = 8080

    @property
    def admin_ids(self) -> List[int]:
        if not self.ADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
