# Telegram Movie Bot (Clean UI Version)

## Features
- Language select (Bangla / English)
- Force join 2 channels
- Search Movie & Series with poster
- Free users: 720p online only (10h expire, no forward)
- Premium: 1080p + download
- Daily auto credit + Promo Code system
- Refer system
- Full Admin Panel (orders, promo generate, stats, user manage...)
- Colored buttons (primary / success / danger)
- Render compatible (web server + polling)

## Setup

1. Copy `.env.example` to `.env` and fill values
2. `pip install -r requirements.txt`
3. Make bot admin in Secret Channel, Update Channel, Backup Channel
4. Run: `python main.py`

## Secret Channel Upload Rules

**Movie:**
- Upload video with caption: `Movie Name #720`
- Upload same movie: `Movie Name #1080`
- Upload poster photo: `Movie Name #thumbnail`

**Series:**
- `Series Name EP 1 #720`
- `Series Name EP 1 #1080`
- Poster: `Series Name #thumbnail`

Bot never shows hashtags to users.

## Render Deploy
- Build Command: `pip install -r requirements.txt`
- Start Command: `python main.py`
- Add all environment variables from `.env`
